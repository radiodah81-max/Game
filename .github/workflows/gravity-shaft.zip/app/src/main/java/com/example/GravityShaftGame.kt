package com.example

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// --- Enums and Data Classes ---

enum class GameState { START, PLAYING, GAME_OVER }

enum class EntityType { OBSTACLE, ENERGY_ORB, SCORE_ORB }

data class GameEntity(
    val id: Int,
    val lane: Int,
    var y: Float,
    val type: EntityType,
    var active: Boolean = true
)

data class Particle(
    var x: Float, var y: Float,
    val vx: Float, val vy: Float,
    var life: Float,
    val maxLife: Float,
    val color: Color
)

// --- Color Palettes ---

data class LevelPalette(val bg: Color, val obstacle: Color, val player: Color)

val palettes = listOf(
    LevelPalette(Color(0xFF0F172A), Color(0xFF06B6D4), Color.White),       // Level 1-5: Dark blue, cyan, white
    LevelPalette(Color(0xFF2E1065), Color(0xFFD946EF), Color(0xFFFACC15)), // Level 6-10: Dark purple, magenta, yellow
    LevelPalette(Color(0xFF052E16), Color(0xFF84CC16), Color(0xFFF97316)), // Level 11-15: Dark green, lime, orange
    LevelPalette(Color(0xFF450A0A), Color(0xFFF472B6), Color.White),       // Level 16-20: Dark red, pink, white
    LevelPalette(Color(0xFF000000), Color(0xFF22C55E), Color(0xFF06B6D4))  // Level 21+: Black, neon green, cyan
)

fun getPaletteForLevel(level: Int): LevelPalette {
    val index = ((level - 1) / 5).coerceIn(0, palettes.size - 1)
    return palettes[index]
}

// --- ViewModel ---

class GameViewModel(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("gravity_shaft", Context.MODE_PRIVATE)

    private val _gameState = MutableStateFlow(GameState.START)
    val gameState = _gameState.asStateFlow()

    private val _score = MutableStateFlow(0)
    val score = _score.asStateFlow()

    private val _highScore = MutableStateFlow(prefs.getInt("high_score", 0))
    val highScore = _highScore.asStateFlow()

    private val _level = MutableStateFlow(1)
    val level = _level.asStateFlow()

    private val _energy = MutableStateFlow(1f)
    val energy = _energy.asStateFlow()

    private val _isGravityFlipped = MutableStateFlow(false)
    val isGravityFlipped = _isGravityFlipped.asStateFlow()

    private val _playerLane = MutableStateFlow(1) // 0, 1, 2
    val playerLane = _playerLane.asStateFlow()

    private val _entities = MutableStateFlow<List<GameEntity>>(emptyList())
    val entities = _entities.asStateFlow()

    private val _particles = MutableStateFlow<List<Particle>>(emptyList())
    val particles = _particles.asStateFlow()

    var screenWidth = 1080f
    var screenHeight = 1920f

    private var entityIdCounter = 0
    private var timeSinceLastSpawn = 0f
    private var timeSinceLastOrbSpawn = 0f
    
    private val baseSpeed = 800f

    fun startGame() {
        _score.value = 0
        _level.value = 1
        _energy.value = 1f
        _isGravityFlipped.value = false
        _playerLane.value = 1
        _entities.value = emptyList()
        _particles.value = emptyList()
        entityIdCounter = 0
        timeSinceLastSpawn = 0f
        timeSinceLastOrbSpawn = 0f
        _gameState.value = GameState.PLAYING
    }

    fun exitToMenu() {
        _gameState.value = GameState.START
    }

    fun moveLeft() {
        if (_gameState.value == GameState.PLAYING && _playerLane.value > 0) {
            _playerLane.value -= 1
        }
    }

    fun moveRight() {
        if (_gameState.value == GameState.PLAYING && _playerLane.value < 2) {
            _playerLane.value += 1
        }
    }

    fun toggleGravity() {
        if (_gameState.value != GameState.PLAYING) return
        if (!_isGravityFlipped.value && _energy.value > 0.1f) {
            _isGravityFlipped.value = true
        } else if (_isGravityFlipped.value) {
            _isGravityFlipped.value = false
        }
    }

    fun update(dt: Float) {
        if (_gameState.value != GameState.PLAYING) return

        // Update Energy
        if (_isGravityFlipped.value) {
            _energy.value = (_energy.value - dt * 0.25f).coerceAtLeast(0f)
            if (_energy.value <= 0f) {
                _isGravityFlipped.value = false
            }
        } else {
            _energy.value = (_energy.value + dt * 0.05f).coerceAtMost(1f)
        }

        // Difficulty scaling
        val currentSpeed = baseSpeed + (_level.value * 50f)
        val scrollDir = if (_isGravityFlipped.value) 1f else -1f
        val dy = scrollDir * currentSpeed * dt

        // Player bounds
        val laneWidth = screenWidth / 3f
        val playerSize = laneWidth * 0.4f
        val playerX = (_playerLane.value * laneWidth) + (laneWidth / 2f)
        val playerY = if (_isGravityFlipped.value) screenHeight * 0.8f else screenHeight * 0.2f

        var hitObstacle = false
        val activeEntities = mutableListOf<GameEntity>()

        // Update & filter entities
        for (e in _entities.value) {
            if (!e.active) continue
            e.y += dy

            // Despawn check
            if (e.y < -500f || e.y > screenHeight + 500f) continue

            // Collision check
            val eX = (e.lane * laneWidth) + (laneWidth / 2f)
            val dx = abs(eX - playerX)
            val dyClose = abs(e.y - playerY)
            
            // Collision hitboxes
            val collideXRange = playerSize * 0.8f
            val collideYRange = if (e.type == EntityType.OBSTACLE) playerSize else playerSize * 1.5f

            if (dx < collideXRange && dyClose < collideYRange) {
                when (e.type) {
                    EntityType.OBSTACLE -> hitObstacle = true
                    EntityType.ENERGY_ORB -> {
                        _energy.value = (_energy.value + 0.3f).coerceAtMost(1f)
                        spawnParticles(eX, e.y, Color.Cyan, 10)
                        e.active = false
                    }
                    EntityType.SCORE_ORB -> {
                        addScore(100)
                        spawnParticles(eX, e.y, Color.Yellow, 10)
                        e.active = false
                    }
                }
            }

            if (e.active) activeEntities.add(e)
        }

        if (hitObstacle) {
            gameOver()
            return
        }

        _entities.value = activeEntities

        // Spawning Logic
        timeSinceLastSpawn += dt
        val spawnInterval = (1.5f - (_level.value * 0.05f)).coerceAtLeast(0.4f)
        if (timeSinceLastSpawn > spawnInterval) {
            timeSinceLastSpawn = 0f
            spawnPattern()
        }

        timeSinceLastOrbSpawn += dt
        if (timeSinceLastOrbSpawn > 2f) {
            timeSinceLastOrbSpawn = 0f
            spawnOrb()
        }

        // Particles
        _particles.value = _particles.value.mapNotNull {
            it.life -= dt
            if (it.life <= 0f) null else {
                it.x += it.vx * dt
                it.y += it.vy * dt
                it
            }
        }

        // Score ticks
        addScore((dt * 10).toInt())
    }

    private fun addScore(points: Int) {
        val newScore = _score.value + points
        _score.value = newScore
        val newLevel = 1 + newScore / 1000
        if (newLevel > _level.value) {
            _level.value = newLevel
        }
    }

    private fun spawnPattern() {
        val spawnY = if (_isGravityFlipped.value) -100f else screenHeight + 100f
        
        val lanes = mutableListOf(0, 1, 2)
        lanes.shuffle()
        val numObstacles = if (Random.nextFloat() > (0.9f - _level.value * 0.02f).coerceAtLeast(0.4f)) 2 else 1
        
        for (i in 0 until numObstacles) {
            _entities.value = _entities.value + GameEntity(entityIdCounter++, lanes[i], spawnY + Random.nextFloat() * 100f, EntityType.OBSTACLE)
        }
    }

    private fun spawnOrb() {
        val spawnY = if (_isGravityFlipped.value) -80f else screenHeight + 80f
        val type = if (Random.nextFloat() > 0.6f) EntityType.ENERGY_ORB else EntityType.SCORE_ORB
        val lane = Random.nextInt(3)
        _entities.value = _entities.value + GameEntity(entityIdCounter++, lane, spawnY, type)
    }

    private fun spawnParticles(x: Float, y: Float, color: Color, count: Int) {
        val newParts = (0 until count).map {
            val angle = Random.nextFloat() * Math.PI * 2
            val speed = Random.nextFloat() * 200f + 50f
            val maxL = 0.5f + Random.nextFloat() * 0.3f
            Particle(
                x, y,
                (cos(angle) * speed).toFloat(), (sin(angle) * speed).toFloat(),
                maxL, maxL, color
            )
        }
        _particles.value = _particles.value + newParts
    }

    private fun gameOver() {
        _gameState.value = GameState.GAME_OVER
        if (_score.value > _highScore.value) {
            _highScore.value = _score.value
            prefs.edit().putInt("high_score", _score.value).apply()
        }
    }
}

// --- Compose UI ---

@Composable
fun GravityShaftApp() {
    val context = LocalContext.current
    val viewModel = remember { GameViewModel(context) }
    val gameState by viewModel.gameState.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when (gameState) {
            GameState.START -> MenuScreen(viewModel)
            GameState.PLAYING -> GameScreen(viewModel)
            GameState.GAME_OVER -> GameOverScreen(viewModel)
        }
    }
}

@Composable
fun MenuScreen(viewModel: GameViewModel) {
    val highScore by viewModel.highScore.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("GRAVITY SHAFT", fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 2.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Spacer(modifier = Modifier.height(16.dp))
        Text("High Score: $highScore", fontSize = 24.sp, color = Color.Cyan, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Spacer(modifier = Modifier.height(48.dp))
        Button(
            onClick = { viewModel.startGame() },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            modifier = Modifier.padding(16.dp).height(56.dp).width(200.dp)
        ) {
            Text("START", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(32.dp))
        Text("Controls:", color = Color.LightGray, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Tap Left/Right to move lanes", color = Color.Gray, fontSize = 16.sp)
        Text("Swipe UP to flip Gravity", color = Color.Gray, fontSize = 16.sp)
        Text("Dodge Red Blocks. Collect Orbs.", color = Color.Gray, fontSize = 16.sp)
    }
}

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val score by viewModel.score.collectAsState()
    val level by viewModel.level.collectAsState()
    val energy by viewModel.energy.collectAsState()
    val isFlipped by viewModel.isGravityFlipped.collectAsState()
    val playerLane by viewModel.playerLane.collectAsState()
    val entities by viewModel.entities.collectAsState()
    val particles by viewModel.particles.collectAsState()
    
    val palette = getPaletteForLevel(level)
    
    // Animate player visual Y position
    val targetYTarget = if (isFlipped) 0.8f else 0.2f
    val animatedPlayerYRatio by animateFloatAsState(targetValue = targetYTarget, animationSpec = tween(300))
    val animatedPlayerRot by animateFloatAsState(targetValue = if (isFlipped) 180f else 0f, animationSpec = tween(300))

    // Ticker
    LaunchedEffect(Unit) {
        var lastTime = System.nanoTime()
        while (isActive) {
            withFrameNanos { time ->
                val dt = (time - lastTime) / 1e9f
                lastTime = time
                viewModel.update(dt)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var totalDragY = 0f
                detectDragGestures(
                    onDragStart = { totalDragY = 0f },
                    onDragEnd = {
                        if (totalDragY < -50f) {
                            viewModel.toggleGravity()
                        } else if (totalDragY > 50f) {
                            viewModel.toggleGravity()
                        }
                    }
                ) { change, dragAmount ->
                    change.consume()
                    totalDragY += dragAmount.y
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        if (offset.x < size.width / 2) viewModel.moveLeft() else viewModel.moveRight()
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            viewModel.screenWidth = size.width
            viewModel.screenHeight = size.height
            val laneWidth = size.width / 3f
            
            // Background
            drawRect(color = palette.bg)

            // Draw lanes visually
            for (i in 1..2) {
                drawLine(
                    color = Color.White.copy(alpha = 0.1f),
                    start = Offset(laneWidth * i, 0f),
                    end = Offset(laneWidth * i, size.height),
                    strokeWidth = 2.dp.toPx()
                )
            }

            // Entities
            for (e in entities) {
                val cx = (e.lane * laneWidth) + (laneWidth / 2f)
                val width = laneWidth * 0.6f
                when (e.type) {
                    EntityType.OBSTACLE -> {
                        drawRoundRect(
                            color = palette.obstacle,
                            topLeft = Offset(cx - width/2, e.y - width/2),
                            size = Size(width, width),
                            cornerRadius = CornerRadius(8.dp.toPx()),
                            style = Stroke(width = 4.dp.toPx())
                        )
                        drawRoundRect(
                            color = palette.obstacle.copy(alpha = 0.3f),
                            topLeft = Offset(cx - width/2, e.y - width/2),
                            size = Size(width, width),
                            cornerRadius = CornerRadius(8.dp.toPx())
                        )
                    }
                    EntityType.ENERGY_ORB -> {
                        drawCircle(color = Color.Cyan, radius = width/3, center = Offset(cx, e.y))
                    }
                    EntityType.SCORE_ORB -> {
                        // Diamond shape
                        withTransform({
                            translate(cx, e.y)
                            rotate(45f)
                        }) {
                            drawRect(color = Color.Yellow, topLeft = Offset(-width/4, -width/4), size = Size(width/2, width/2))
                        }
                    }
                }
            }

            // Particles
            for (p in particles) {
                val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
                drawRect(
                    color = p.color.copy(alpha = alpha),
                    topLeft = Offset(p.x, p.y),
                    size = Size(10f, 10f)
                )
            }

            // Player
            val playerX = (playerLane * laneWidth) + (laneWidth / 2f)
            val playerY = size.height * animatedPlayerYRatio
            val pSize = laneWidth * 0.4f
            
            withTransform({
                translate(playerX, playerY)
                rotate(animatedPlayerRot)
            }) {
                // Triangle ship
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, pSize)
                    lineTo(-pSize / 2, -pSize / 2)
                    lineTo(pSize / 2, -pSize / 2)
                    close()
                }
                drawPath(path, color = palette.player)
                drawPath(path, color = Color.Black, style = Stroke(width = 3.dp.toPx()))
            }
        }
        
        // HUD Overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "SCORE", fontSize = 12.sp, color = Color.White)
                Text(text = score.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            
            // Energy Bar
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(16.dp)
                    .background(Color.DarkGray, shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction = energy)
                        .fillMaxHeight()
                        .background(Color.Cyan, shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                )
            }
            
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "LEVEL", fontSize = 12.sp, color = Color.White)
                Text(text = level.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        // Exit Button
        IconButton(
            onClick = { viewModel.exitToMenu() },
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 100.dp, end = 16.dp)
        ) {
            Text("X", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun GameOverScreen(viewModel: GameViewModel) {
    val score by viewModel.score.collectAsState()
    val highScore by viewModel.highScore.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("GAME OVER", fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, color = Color.Red, letterSpacing = 2.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Final Score: $score", fontSize = 24.sp, color = Color.White, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Text("High Score: $highScore", fontSize = 24.sp, color = Color.Cyan, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Spacer(modifier = Modifier.height(48.dp))
        Button(
            onClick = { viewModel.startGame() },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            modifier = Modifier.padding(8.dp).height(56.dp).width(200.dp)
        ) {
            Text("RESTART", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Button(
            onClick = { viewModel.exitToMenu() },
            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray, contentColor = Color.White),
            modifier = Modifier.padding(8.dp).height(56.dp).width(200.dp)
        ) {
            Text("MAIN MENU", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}
